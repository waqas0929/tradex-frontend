import api from '../Api/api'

export const getUser = () => api.get('./user')